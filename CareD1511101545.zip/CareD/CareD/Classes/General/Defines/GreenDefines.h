//
//  GreenDefines.h
//  CareD
//
//  Created by LakesMac on 15/11/9.
//  Copyright © 2015年 Tec-Erica. All rights reserved.
//

#ifndef GreenDefines_h
#define GreenDefines_h


#endif /* GreenDefines_h */
