//
//  HYDefines.h
//  CareD
//
//  Created by LakesMac on 15/11/9.
//  Copyright © 2015年 Tec-Erica. All rights reserved.
//

#ifndef HYDefines_h
#define HYDefines_h



#endif /* HYDefines_h */
